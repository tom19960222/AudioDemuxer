﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediaInfoLib;

namespace MediaInfoLib
{
    public partial class MediaInfo
    {
        public int VideoTracksCount 
        {
            get { return this.Count_Get(StreamKind.Video); }
        }

        public int AudioTracksCount
        {
            get { return this.Count_Get(StreamKind.Audio); }
        }

        public int SubTracksCount
        {
            get { return this.Count_Get(StreamKind.Text); }
        }

        public int GeneralTracksCount
        {
            get { return this.Count_Get(StreamKind.General); }
        }

        public int OtherTracksCount
        {
            get { return this.Count_Get(StreamKind.Other); }
        }
    }
}
