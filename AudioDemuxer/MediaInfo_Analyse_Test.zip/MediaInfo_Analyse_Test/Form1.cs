﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediaInfoLib;

namespace MediaInfo_Analyse_Test
{
    public partial class Form1 : Form
    {
        OpenFileDialog OFD = new OpenFileDialog();
        MediaInfo MI = new MediaInfo();
        string outputBuffer = String.Empty;
        string temp = String.Empty;
        public Form1()
        {
            InitializeComponent();
            OFD.FileOk += OFD_FileOk;
        }

        void OFD_FileOk(object sender, CancelEventArgs e)
        {
            textBox1.Text = OFD.FileName;
            MI.Open(OFD.FileName);
            outputBuffer += String.Format("Video track count: {0}\r\n\r\n", MI.VideoTracksCount.ToString());
            outputBuffer += String.Format("Audio track count: {0}\r\n\r\n", MI.AudioTracksCount.ToString());
            outputBuffer += String.Format("General track count: {0}\r\n\r\n", MI.GeneralTracksCount.ToString());
            for (int i = 0; i < MI.VideoTracksCount; i++)
            {
                outputBuffer += String.Format("Video #{1}\tID: {0}\r\n", MI.Get(StreamKind.Video, i, "ID/String"), i + 1);
                outputBuffer += String.Format("Format: {0}\r\n", MI.Get(StreamKind.Video, i, "Format"));
                outputBuffer += "\r\n";
            }
            for (int i = 0; i < MI.AudioTracksCount; i++)
            {
                outputBuffer += String.Format("Audio #{1}\tID: {0}\r\n", MI.Get(StreamKind.Audio, i, "ID/String"), i + 1);
                outputBuffer += String.Format("Format: {0}\r\n", MI.Get(StreamKind.Audio, i, "Format"));
                outputBuffer += "\r\n";
            }
            textBox2.Text = outputBuffer;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OFD.ShowDialog();
        }
    }
}
